# DJ KEVIN MABAYI — Music Market
Frontend starter for a Burundi music/video marketplace.

## Important
This is a static frontend demo. GitHub Pages can publish HTML/CSS/JS, but it does not run server-side PHP/Python/Ruby. A real marketplace needs a backend/database and a secure payment gateway integration.

## Next production steps
1. Backend + database
2. Artist accounts and authentication
3. Real audio/video storage
4. Admin moderation
5. Rimicash merchant/API integration
6. Monthly subscription webhooks
7. Secure download/access control
8. Google SEO, sitemap and Search Console
